/* ui.js - behavior for hamburger, mobile submenu and modal */
document.addEventListener('DOMContentLoaded', function(){
  const hamburger = document.getElementById('hamburgerBtn');
  const mobileMenu = document.getElementById('mobileMenu');
  if(hamburger){
    hamburger.addEventListener('click', function(){
      const open = mobileMenu.classList.toggle('open');
      mobileMenu.setAttribute('aria-hidden', !open);
      hamburger.setAttribute('aria-expanded', open);
    });
  }
  document.querySelectorAll('[data-mobile-submenu-toggle]').forEach(btn=>{
    btn.addEventListener('click', function(){
      const submenu = this.nextElementSibling;
      if(!submenu) return;
      submenu.classList.toggle('hidden');
    });
  });
  const openModalBtn = document.getElementById('openModal');
  const modalBackdrop = document.getElementById('modalBackdrop');
  const closeModalBtn = document.getElementById('closeModal');
  if(openModalBtn && modalBackdrop){
    openModalBtn.addEventListener('click', function(){
      modalBackdrop.classList.add('open');
      modalBackdrop.setAttribute('aria-hidden','false');
    });
  }
  if(closeModalBtn && modalBackdrop){
    closeModalBtn.addEventListener('click', function(){
      modalBackdrop.classList.remove('open');
      modalBackdrop.setAttribute('aria-hidden','true');
    });
  }
  if(modalBackdrop){
    modalBackdrop.addEventListener('click', function(e){
      if(e.target === modalBackdrop){
        modalBackdrop.classList.remove('open');
        modalBackdrop.setAttribute('aria-hidden','true');
      }
    });
  }
  const form = document.getElementById('formCadastro');
  if(form){
    form.addEventListener('submit', function(e){
      if(!form.checkValidity()){
        e.preventDefault();
        form.reportValidity();
      } else {
        e.preventDefault();
        alert('Form válido — aqui você enviaria para servidor.');
      }
    });
  }
});
